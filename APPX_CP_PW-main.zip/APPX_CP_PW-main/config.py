api_id = "10170481"
api_hash = "22dd74455eb31c9aca628c3008580142"
bot_token = "8433886804:AAGyxrEGWE8sL7nbeNHUJW07zINBoIFIBls"
auth_users = [8048202739]
