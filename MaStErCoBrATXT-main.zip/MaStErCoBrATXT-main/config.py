import os
from os import getenv



# ------------------------------------------------
API_ID = int(os.environ.get("API_ID", "25933223"))
# ------------------------------------------------
API_HASH = os.environ.get("API_HASH","6ef5a426d85b7f01562a41e6416791d3")
# ------------------------------------------------
BOT_TOKEN = os.environ.get("BOT_TOKEN", "8036273889:AAFdoAgGDEEwcQJ3TDq8ABqPqRuY-7oOvfk")
# ------------------------------------------------
BOT_USERNAME = os.environ.get("BOT_USERNAME", "@SuJaLtxtoopvbot")
BOT_TEXT = "𝐏𝐑𝐎 𝐄𝐗𝐓𝐑𝐀𝐂𝐓𝐎𝐑 Sᑌᒍᗩᒪ"
# ------------------------------------------------
OWNER_ID = int(os.environ.get("OWNER_ID", "6883471516"))
# ------------------------------------------------
# //LOG CHANNEL ID 
CHANNEL_ID = int(os.environ.get("CHANNEL_ID", "-1002799217873"))

# //FORCE_CHANNEL_ID
CHANNEL_ID2 = int(os.environ.get("CHANNEL_ID2", "-1002842513893")) 
# -----------------------------------------------
MONGO_URL = os.environ.get("MONGO_URL", "mongodb+srv://biklriplit:efaXfv2Ps9MRfner@cluster0.4hfu8zj.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0")
# -----------------------------------------------
PREMIUM_LOGS = int(os.environ.get("PREMIUM_LOGS", "-1002799217873"))
# -----------------------------------------------
join = '<a href="https://t.me/+VZXbQJx9UgZjOWNl">✳️ Bᴀᴄᴋᴜᴘ</a>'
# -----------------------------------------------
UNSPLASH_ACCESS_KEY = 'RabDRmuXXBobanmwwbvpP5LwoG4J8ox34y5Sstz-9jk'
# -----------------------------------------------
UNSPLASH_QUERY = 'animal baby'
# -----------------------------------------------
ADMIN_BOT_USERNAME = "youcndoitbro" #without @

THUMB_URL = os.environ.get("THUMB_URL", "https://i.ibb.co/mFv7r6H4/d997e7637c2a.jpg")




# # Bot configuration
# API_ID = int(os.environ.get("API_ID", "22746239"))
# API_HASH = os.environ.get("API_HASH", "a98ec8cfd8572a3a7c936cf828fe6215")
# BOT_TOKEN = os.environ.get("BOT_TOKEN", "7547829346:AAGyfvOu47EciNhC7NUGSDEDFuBaetYYusw")
# BOT_USERNAME = os.environ.get("BOT_USERNAME", "MassRPBot")
# OWNER_ID = int(os.environ.get("OWNER_ID", "7463601722"))
# SUDO_USERS = list(map(int, getenv("SUDO_USERS", "7463601722").split()))
# CHANNEL_ID = int(os.environ.get("CHANNEL_ID", "-1002601604234"))
# MONGO_URL = os.environ.get("MONGO_URL", "mongodb+srv://wadiro6523:08AwfhhKRdQaS1i6@cluster0.krzxuop.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0")
# PREMIUM_LOGS = int(os.environ.get("PREMIUM_LOGS", "-1002601604234"))
# THUMB_URL = os.environ.get("THUMB_URL", "https://i.fbcd.co/products/original/ug-circle-logo-design-2-e84695ca2ab9a697d2b2d7c928b0bf5f12bf18e076da241815e0372c8d617915.jpg")

