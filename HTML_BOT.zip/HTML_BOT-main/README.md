# 📄 TXT to HTML Converter

🚀 **TXT to HTML Converter** एक आसान Python टूल है जो किसी भी `.txt` फाइल को सुंदर और व्यवस्थित **HTML फाइल** में बदल देता है।  
यह उन प्रोजेक्ट्स, बॉट्स, या वेबसाइट्स के लिए परफेक्ट है जिन्हें टेक्स्ट को वेब-फ्रेंडली फॉर्मैट में दिखाना हो।  

---

## ✨ Features
- ✅ **Simple & Fast** – एक ही रन में txt को html में बदल देता है।
- ✅ **Automatic File Naming** – सिर्फ फाइल का नाम रखता है, पूरा path नहीं।
- ✅ **Clean Output** – HTML में proper formatting और basic styling।
- ✅ **Works Anywhere** – Telegram bot, CLI, या automation script में use कर सकते हैं।

---

## 📦 Installation

```bash
git clone https://github.com/your-username/txt-to-html.git
cd txt-to-html
pip install -r requirements.txt
