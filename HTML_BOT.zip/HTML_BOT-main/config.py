BOT_TOKEN = ""
API_ID =    
API_HASH =""
ADMINS = []
OWNER_ID = 
LOG_CHANNEL =




